import Vue from 'vue'
import VueRouter, { RouteConfig } from 'vue-router'

import MainLayout from '@/components/layout/MainLayout.vue'
import HomeView from '@/views/HomeView.vue'
import AboutView from '@/views/AboutView.vue'

Vue.use(VueRouter)

const routes: Array<RouteConfig> = [
  {
    path: '/',
    component: MainLayout,
    children: [
      {
        path: '',
        name: 'home',
        component: HomeView,
      },
      {
        path: 'about',
        name: 'about',
        component: AboutView,
      },
    ],
  },
]

const router = new VueRouter({
  mode: 'hash',
  routes,
})

export default router