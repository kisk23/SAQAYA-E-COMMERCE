import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export interface RootState {
  count: number
}

export default new Vuex.Store<RootState>({

})
