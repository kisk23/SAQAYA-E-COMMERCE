<template>
  <header class="header">
    <div class="header-container">
    
      <div class="logo">
        <span>Exclusive</span>
      </div>

   
      <nav class="nav-menu">
        <router-link to="/">Home</router-link>
        <router-link to="/contact">Contact</router-link>
        <router-link to="/about">About</router-link>
      </nav>

     
      <div class="search-cart-wrapper">
  
        <div class="search-bar">
          <input
            type="text"
            placeholder="What are you looking for?"
          />
          <button class="search-btn">
            <svg
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              ></path>
            </svg>
          </button>
        </div>

       
        <button class="cart-btn">
         <img
          src="@/assets/images/Cart1.png"
            alt="Cart"
          />
          <span class="cart-badge">2</span>
        </button>
      </div>
    </div>
  </header>
</template>

<script lang="ts">
import Vue from 'vue'
 
export default Vue.extend({
  name: 'HeaderSection',
})
</script>

<style scoped>
.header {
  width: 100%;
  background-color: #ffffff;
  border-bottom: 1px solid #e5e7eb;
  margin-top: 48px;
}

.header-container {
  max-width: 1280px;
  margin: 0 auto;
  padding: 1rem 1.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 2rem;
}

.logo {
  flex-shrink: 0;

}

.logo span {
  font-size: 1.25rem;
  font-weight: 700;
  color: #111827;
}

.nav-menu {
  display: none;
  align-items: center;
  gap: 2rem;
  margin-left: 20%;
}

.nav-menu a {
  font-size: 0.875rem;
  color: #374151;
  text-decoration: none;
  transition: color 0.2s ease;
}

.nav-menu a:hover {
  color: #111827;
   text-decoration: underline; 


}

.search-cart-wrapper {
  height: 38px;
  min-height: 38px;
  max-height: 38px;
  display: flex;
  align-items: center;
  gap: 1.5rem;
  flex: 1;
  justify-content: flex-end;
}

.search-bar {
  display: none;
  align-items: center;
  background-color: #f3f4f6;
  border-radius: 0.375rem;
  padding: 0.5rem 1rem;
}

.search-bar input {
  background: transparent;
  font-size: 0.875rem;
  color: #374151;
  border: none;
  outline: none;
  width: 12rem;
}

.search-bar input::placeholder {
  color: #9ca3af;
}

.search-btn {
  background: none;
  border: none;
  color: #4b5563;
  cursor: pointer;
  margin-left: 0.5rem;
  transition: color 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 2rem;
  height: 2rem;
}

.search-btn:hover {
  color: #111827;
}

.search-btn svg {
  width: 100%;
  height: 100%;
}

.cart-btn {
  position: relative;
  background: none;
  border: none;
  color: #374151;
  cursor: pointer;
  transition: color 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 1.5rem;
  height: 1.5rem;
}




.cart-badge {
  position: absolute;
  top: -0.5rem;
  right: -0.5rem;
  background-color: #ef4444;
  color: #ffffff;
  font-size: 0.75rem;
  font-weight: 700;
  border-radius: 50%;
  width: 1.25rem;
  height: 1.25rem;
  display: flex;
  align-items: center;
  justify-content: center;
}


@media (min-width: 768px) {
  .nav-menu {
    display: flex;
  }
}

@media (min-width: 1024px) {
  .search-bar {
    display: flex;
  }
}
</style>
