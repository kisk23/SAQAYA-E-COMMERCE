<template>
  <footer class="footer">
    <div class="footer-container">
   
      <div class="footer-section exclusive">
        <h3 class="section-title">Exclusive</h3>
        <p class="subscribe-subtitle">Subscribe</p>
        <p class="subscribe-text">Get 10% off your first order</p>
        <div class="email-input-wrapper">
          <input 
            type="email" 
            placeholder="Enter your email" 
            class="email-input"
            aria-label="Email subscription"
          >
          <button class="submit-btn" aria-label="Subscribe">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
          </button>
        </div>
      </div>

  
      <div class="footer-section support">
        <h3 class="section-title">Support</h3>
        <p class="support-item">111 Bijoy sarani, Dhaka<br>DH 1515, Bangladesh.</p>
        <p class="support-item"><a href="mailto:exclusive@gmail.com">exclusive@gmail.com</a></p>
        <p class="support-item"><a href="tel:+880158888999">+88015-88888-9999</a></p>
      </div>

    
      <div class="footer-section account">
        <h3 class="section-title">Account</h3>
        <ul class="link-list">
          <li><a href="#" class="footer-link">My Account</a></li>
          <li><a href="#" class="footer-link">Login / Register</a></li>
          <li><a href="#" class="footer-link">Cart</a></li>
          <li><a href="#" class="footer-link">Wishlist</a></li>
          <li><a href="#" class="footer-link">Shop</a></li>
        </ul>
      </div>

    
      <div class="footer-section quick-links">
        <h3 class="section-title">Quick Link</h3>
        <ul class="link-list">
          <li><a href="#" class="footer-link">Privacy Policy</a></li>
          <li><a href="#" class="footer-link">Terms Of Use</a></li>
          <li><a href="#" class="footer-link">FAQ</a></li>
          <li><a href="#" class="footer-link">Contact</a></li>
        </ul>
      </div>

      <!-- Download App Section -->
      <div class="footer-section download-app">
        <h3 class="section-title">Download App</h3>
        <p class="app-text">Save $3 with App New User Only</p>
        <div class="app-content">
          <div class="qr-code">
            <img src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Crect fill='%23fff' width='80' height='80'/%3E%3C/svg%3E" alt="QR Code" class="qr-image">
          </div>
          <div class="app-buttons">
            <button class="app-store-btn" aria-label="Download on Google Play">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M3.609 1.814L13.792 12 3.609 22.186A1.5 1.5 0 0 1 1.5 21V3a1.5 1.5 0 0 1 2.109-1.186zm16.959.404l-9.5 9.5 9.5 9.5c.781.781 2.047.78 2.828 0l2.121-2.121c.78-.78.78-2.047 0-2.828L10.586 12l9.5-9.5c.78-.78.78-2.047 0-2.828l-2.121-2.121c-.78-.78-2.046-.781-2.828 0z"/>
              </svg>
              Google Play
            </button>
            <button class="app-store-btn" aria-label="Download on App Store">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
                <path d="M17.05 13.5c-.02-1.5.87-2.83 2.2-3.72-.97-1.42-2.51-2.26-4.36-2.26-3.67 0-6.59 2.35-6.59 6.48 0 4.13 2.92 6.48 6.59 6.48 1.85 0 3.39-.84 4.36-2.26-1.33-.9-2.22-2.22-2.2-3.72z"/>
              </svg>
              App Store
            </button>
          </div>
        </div>
      </div>
    </div>

  
    <div class="social-icons">
      <a href="#" class="social-link" aria-label="Facebook">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
      </a>
      <a href="#" class="social-link" aria-label="Twitter">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
          <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2s9 5 20 5a9.5 9.5 0 00-9-5.5c4.75-2.35 7-7 7-11.667z"/>
        </svg>
      </a>
      <a href="#" class="social-link" aria-label="Instagram">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
          <rect x="2" y="2" width="20" height="20" rx="5" ry="5" fill="none" stroke="currentColor" stroke-width="2"/>
          <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37z" fill="currentColor"/>
          <circle cx="17.5" cy="6.5" r="1.5" fill="currentColor"/>
        </svg>
      </a>
      <a href="#" class="social-link" aria-label="LinkedIn">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
          <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.475-2.236-1.986-2.236-1.081 0-1.722.722-2.004 1.418-.103.249-.129.597-.129.946v5.441h-3.554s.05-8.836 0-9.759h3.554v1.381c.43-.664 1.199-1.608 2.948-1.608 2.153 0 3.767 1.408 3.767 4.435v5.551zM5.337 9.432c-1.144 0-1.915-.758-1.915-1.704 0-.951.77-1.704 1.959-1.704 1.188 0 1.914.753 1.939 1.704 0 .946-.751 1.704-1.983 1.704zm1.581 11.02H3.819V9.693h3.099v10.759zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
        </svg>
      </a>
    </div>

    <div class="copyright">
      <p>&copy; Copyright Rimel 2022. All right reserved</p>
    </div>
  </footer>
</template>

<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
  name: 'FooterSection',
})
</script>

<style scoped>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.footer {
  background-color: #000;
  color: #fff;
  padding: 40px 20px;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
}

.footer-container {
  max-width: 1200px;
  margin: 0 auto 40px;
  display: grid;
  grid-template-columns: 1fr;
  gap: 30px;
}

.footer-section {
  padding: 10px 0;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 16px;
  text-transform: capitalize;
}


.exclusive {
  display: flex;
  flex-direction: column;
}

.subscribe-subtitle {
  font-size: 14px;
  font-weight: 500;
  margin-bottom: 8px;
}

.subscribe-text {
  font-size: 12px;
  color: #ccc;
  margin-bottom: 16px;
}

.email-input-wrapper {
  display: flex;
  border: 1px solid #666;
  border-radius: 4px;
  overflow: hidden;
}

.email-input {
  flex: 1;
  background-color: transparent;
  border: none;
  padding: 12px 16px;
  color: #fff;
  font-size: 14px;
  outline: none;
}

.email-input::placeholder {
  color: #999;
}

.submit-btn {
  background-color: transparent;
  border: none;
  color: #fff;
  padding: 12px 16px;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background-color 0.3s;
}

.submit-btn:hover {
  background-color: #333;
}


.support {
  line-height: 1.8;
}

.support-item {
  font-size: 14px;
  color: #ccc;
  margin-bottom: 12px;
}

.support-item a {
  color: #ccc;
  text-decoration: none;
  transition: color 0.3s;
}

.support-item a:hover {
  color: #fff;
}


.account,
.quick-links {
  line-height: 2;
}

.link-list {
  list-style: none;
}

.link-list li {
  margin-bottom: 8px;
}

.footer-link {
  color: #ccc;
  text-decoration: none;
  font-size: 14px;
  transition: color 0.3s;
}

.footer-link:hover {
  color: #fff;
}


.app-text {
  font-size: 12px;
  color: #ccc;
  margin-bottom: 12px;
}

.app-content {
  display: flex;
  gap: 12px;
  align-items: flex-start;
}

.qr-code {
  width: 80px;
  height: 80px;
  background-color: #fff;
  padding: 4px;
  border-radius: 4px;
  flex-shrink: 0;
}

.qr-image {
  width: 100%;
  height: 100%;
  object-fit: contain;
}

.app-buttons {
  display: flex;
  flex-direction: column;
  gap: 8px;
  justify-content: center;
}

.app-store-btn {
  background-color: transparent;
  border: 1px solid #666;
  color: #fff;
  padding: 8px 12px;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
  display: flex;
  align-items: center;
  gap: 6px;
  transition: border-color 0.3s, color 0.3s;
}

.app-store-btn:hover {
  border-color: #999;
  color: #fff;
}


.social-icons {
  display: flex;
  gap: 16px;
  justify-content: center;
  margin: 20px 0;
  border-top: 1px solid #333;
  padding-top: 20px;
  border-bottom: 1px solid #333;
  padding-bottom: 20px;
}

.social-link {
  color: #fff;
  text-decoration: none;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: color 0.3s;
}

.social-link:hover {
  color: #0066ff;
}

/* Copyright */
.copyright {
  text-align: center;
  padding-top: 20px;
  font-size: 12px;
  color: #666;
}

.copyright p {
  margin: 0;
}


@media (min-width: 768px) {
  .footer-container {
    grid-template-columns: repeat(2, 1fr);
    gap: 40px;
  }

  .section-title {
    font-size: 18px;
  }
}


@media (min-width: 1024px) {
  .footer-container {
    grid-template-columns: repeat(5, 1fr);
    gap: 30px;
  }

  .footer {
    padding: 60px 20px;
  }

  .footer-section {
    padding: 0;
  }

  .email-input-wrapper {
    width: 100%;
  }

  .app-content {
    flex-direction: column;
    align-items: flex-start;
  }

  .app-buttons {
    width: 100%;
  }

  .app-store-btn {
    width: 100%;
    justify-content: center;
  }
}


@media (min-width: 1440px) {
  .footer-container {
    gap: 40px;
  }
}
</style>
