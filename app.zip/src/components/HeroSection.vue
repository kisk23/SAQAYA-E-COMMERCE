
<template>
  <section class="hero">
    <div class="container">
      <h1>
        Welcome to my website
      </h1>
      <p>
        This is a website built with Vue.js and TypeScript.
      </p>
      <button class="btn">
        Learn more
      </button>
    </div>
  </section>
</template>
<script lang="ts">
import Vue from 'vue'

export default Vue.extend({
    name: 'HeroSection',
})
</script>

<style scoped>
  .hero {
    background-color: #35495e;
    color: white;
    padding: 2rem;
    text-align: center;
  }

  .hero .container {
    max-width: 600px;
    margin: 0 auto;
  }

  .hero h1 {
    font-size: 2rem;
  }

  .hero p {
    font-size: 1.2rem;
  }

  .hero .btn {
    background-color: #42b983;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
  }
</style>
