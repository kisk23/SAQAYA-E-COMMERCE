import { createLocalVue, shallowMount } from '@vue/test-utils'
import type { CreateElement } from 'vue'
import VueRouter from 'vue-router'
import Vuex from 'vuex'
import App from '@/App.vue'

const localVue = createLocalVue()
localVue.use(VueRouter)
localVue.use(Vuex)

describe('App.vue', () => {
 // tests will be here
})
